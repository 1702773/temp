#ifndef Time_H_
#define Time_H_

class Time
{
public:
int h;
int m;
int totletime_h;
int totletime_m;

Time(int h1,int m1);
Time();

bool operator< (Time & t);
bool operator== (Time & t);
bool operator<= (Time & t);
float operator- (Time &t);
bool operator>= (Time &t);
void operator= (const Time &t);
};

#endif

