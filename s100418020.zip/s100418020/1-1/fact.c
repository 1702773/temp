#include <stdio.h>


int fact2(int n)
{
  int result=1;
  if((n-1)>0)
    result= n * fact2(n-1);
  else
    result=1;
  return result;
}

int fact(int n)
{
  int i;
  int result=1;
  
  for(i=n;i>0;i--)
    result=result*i;
  return result;
}


int main()
{
  int n;

  int i=0;
  int result =1;
  
  
  scanf("%d", &n);
  
  printf("n=%d n!=%d\n", n, fact2(n));
}
