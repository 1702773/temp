#include <iostream>
//#include <string>
#include "Time.h"

Time::Time(int h1,int m1)
{
h = h1;
m = m1;
totletime_h = 0;
totletime_m = 0;
}

Time::Time ()
{
h = 0;
m = 0;
totletime_h = 0;
totletime_m = 0;
}

void Time::operator= (const Time & t)
{
h = t.h;
m = t.m;
}

bool Time::operator <(Time & t )
{
if (h < t.h)
return 1;
if ((h == t.h)&&(m < t.m))
return 1;
else
return 0;
}

bool Time::operator== (Time & t)
{
if ((h == t.h) && (m == t.m) )
return 1;
else
return 0;
}

bool Time::operator<= (Time & t)
{
if (h < t.h)
return 1;
if ((h == t.h)&&(m <= t.m))
return 1;
else
return 0;

}

float Time::operator- (Time & t)
{
int i,j,t1,t2,x;
float temp = 0.0;
j = 0;
t1 = h * 60 + m;
t2 = t.h * 60 + t.m;
x = t1 - t2;
i = x % 60;
j = x / 60;
t.totletime_m = t.totletime_m + i;
t.totletime_h = t.totletime_h + j ;
temp = float(j) + float(i)/60;

return temp;
}

bool Time::operator>= (Time & t)
{
if (h > t.h)
return 1;
else if (h == t.h && m > t.m)
return 1;
else
return 0;
}

