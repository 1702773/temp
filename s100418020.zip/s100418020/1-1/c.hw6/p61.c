#include <stdio.h>

int main (void)
{
float i,max=0;

printf("Enter a number:\n");
scanf("%f",&i);

while (i != 0)
{
if (max<i) max=i;
 
printf("Enter a number:\n");
scanf("%f",&i); 

}

printf("The largest number entered was %g\n",max);

return 0;

}

