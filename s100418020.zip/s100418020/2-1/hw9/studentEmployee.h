#ifndef studentEmployee_H_
#define studentEmployee_H_

#include <string>
#include "Time.h"
#define pay_per_hour 100


class StudentEmployee
{

private:
public:
int id;
Time checkin;
char name[21];
float wHours;
float salary;

friend int find_empty_slot();
friend int find_slot(int fid);
friend void check_in();
friend void check_out();
friend void delete_a_student();
friend void copy_to_create();
friend void show_all_student_employees_information();
friend void show_student_employee_information();

StudentEmployee(int ids ,const char * names);
StudentEmployee();//寫一剛開始 全部id都為0的
~StudentEmployee();
void operator= (const StudentEmployee &s);
void operator= (Time & t);
friend std::ostream & operator<<(std::ostream & os , StudentEmployee & s);
};

#endif

