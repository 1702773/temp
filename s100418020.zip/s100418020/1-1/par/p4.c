#include <stdio.h>
int main(void)
{
int a,b,y=1,c,w=1,x,z=1;
for (a=1;a<=4;a++)
{
  for (b=1;b<=y;b++) {printf("*");}
  for (c=7;c>=w;c--) {printf("@");}
  for (x=1;x<=z;x++) {printf("*");}
  
  printf("\n");
  y++;
  w+=2;
  z++;
}

printf("*********\n");

return 0;
}

