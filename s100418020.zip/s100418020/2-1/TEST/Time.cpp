#include "Time.h"

Time::Time()
{
  h = m = 0 ;

}

Time::Time(int sh,int sm)
{
  h = sh;
  m = sm;
}

void Time::operator=(const Time & t)
{
  h = t.h;
  m = t.m;  

}



