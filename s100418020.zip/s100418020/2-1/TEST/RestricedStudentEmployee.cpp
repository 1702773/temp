#include "Student.h"
#include "StudentEmployee.h"
#include "RestricedStudentEmployee.h"

using namespace std;

RestricedStudentEmployee::RestricedStudentEmployee(char *n, char*i,int ubh ,long ubs)
{
  strcpy(name,n);
  strcpy(id,i);
  UBHours = ubh;
  UBSalary = ubs;
  
}

RestricedStudentEmployee::RestricedStudentEmployee()
{
  strcpy (name,"empty");
  strcpy (id,"empty");
  UBHours = 0;
  UBSalary = 0;
 
 
}

void RestricedStudentEmployee::showInfo()
{
  cout << name << "(" << id << "),[NT." <<  UBSalary  << "/" << UBHours << "hrs]," << hours.h 
       << ":" << hours.m << ", NT." << salary << endl;
}

void RestricedStudentEmployee::checkOut(Time &t)
{
   hours.m = t.m - checkin.m;
   float z; // 算時薪多少
     if (hours.m < 0)
     {
        t.h--;
        hours.m += 60; // 向 t.h 借位
     }
     
        hours.h += t.h - checkin.h;
     
     z = float(UBSalary) / float(UBHours);
     salary = (long (float(hours.h) * z)) + long ( float (hours.m) / 60 * z);
     
     if (salary > UBSalary)
     salary = UBSalary;     
                           
}

