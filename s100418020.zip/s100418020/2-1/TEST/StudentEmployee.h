#ifndef StudentEmployee_H_
#define StudentEmployee_H_
#include <iostream>
#include <string>
#include "Time.h"
#define pay_per_hour 100


//using namespace std;

class StudentEmployee : public Student
{
  public:
      Time checkin;
      Time hours;
      long salary;
  
      StudentEmployee(const char * n ,char * i);
      StudentEmployee();
      virtual void showInfo();
      void checkIn(const Time);                             
      void checkOut(Time &t);
      //void add_eight_hours(Time &h); ///      
};


#endif                            





