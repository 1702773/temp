#include <iostream>
#include "studentEmployee.h"

using namespace std;

void check_in();
void check_out();
void create_a_new_student_employee();
void show_all_student_employees_information();
void show_student_employee_information();
void copy_to_create();
void delete_a_student();

int 	getID();
Time 	getTime();
void getName(char * n);

StudentEmployee emp[10];
int inx=0;

int main()
{
  char cmd;
  int quit=0;

  while(!quit)
    {
      cout << "Operation Code:";
      cin >> cmd;
      cin.get(); // read the newline
      
      switch(cmd)
	{
	case 'q':
	  quit=1;
	  break;
	case 'i': // check In for the job 	  
	  check_in();
	  break;
	case 'o': // check Out for the job
	  check_out();
	  break;
	case 's': // show the specified student employee's record
	  show_student_employee_information();
	  break;
	case 't': // show the salary table of all student employeess
	  show_all_student_employees_information();
	  break;
	case 'n': // create a new student employee
	  create_a_new_student_employee();
	  break;
	case 'c': // copy a student's record to generate a new empolyee
	  copy_to_create(); 
	  break;
	case 'd': // delete a student empolyee
	  delete_a_student();
	  break;
	default:
	  cout << "Invaild operation code!" << endl;
	}
    }

  return 0;
}

void getName(char * name)
{
  cout << "Enter student's name:";
  cin.get(name, 21).get();
}

int find_empty_slot()
{
  int i;
  
  for(i=0;i<10;i++)
  {
    if(emp[i].id==0)
    {
      return i;
    }
  }
  return (-1);
}

int getID()
{
  int id;
  cout << "Enter student's ID:";
  cin >> id;
  cin.get();
  return id;
}

int find_slot(int fid)
{
  int i;
  for(i=0;i<10;i++)
  {
    if(emp[i].id==fid)
      return i;
  }
  return (-1);
}

void check_in()
{
  int i,id,h,m;
  
  id = getID();

  if( (i=find_slot(id))==(-1) )
  {
    cout << "This student is not our employee!" << endl;
  }
  else
  {
    cout << "Enter Check-In Time:" << endl;
    emp[i].checkin = getTime();
    cout << emp[i];
  }
}




Time getTime()
{
  Time t;
  int h,m;
  cout << "Enter a time (HH:MM):";
  scanf("%2d:%2d", &h, &m);
  t = Time(h,m);
  return t;
}

void check_out()
{
  int id,i;
  
  if( (i=find_slot(id=getID()))==(-1) )
  {
    cout << "This student is not our employee!" << endl;
  }
  else
  {
    Time checkout;
    Time night(18,0);
    checkout = getTime();
    
    if(checkout < emp[i].checkin)
    {
      cout << "Overnight is not allowed!" << endl;
    }
    else if(checkout==emp[i].checkin)
    {
      cout << "The check-in and check-out time are the same!" << endl;
    }
    else if((emp[i].checkin < night )&&(checkout <= night))
    {
        emp[i].wHours = emp[i].wHours + (checkout - emp[i].checkin);
    }
    else if((emp[i].checkin < night)&&(checkout >= night))
    {
        emp[i].wHours = emp[i].wHours + (night- emp[i].checkin);
        emp[i].wHours = emp[i].wHours + ((checkout - night)*1.5);
    }
    else if(emp[i].checkin >= night)
    {
        emp[i].wHours = emp[i].wHours + ((checkout - emp[i].checkin) * 1.5);
    }
    
    emp[i].salary = emp[i].wHours* pay_per_hour;
    cout << emp[i];
  }
}

void delete_a_student()
{
  int i,id;
  
  id=getID();
  i=find_slot(id);
  if(i==(-1))
  {
    cout << "This sutdent is not our employee!" << endl;
  }
  else
  {
    emp[i].id=0;
  }
}

void copy_to_create()
{
  int idfrom, idto, i, j;
  char name[21];
  
  cout << "Copy from:" << endl;

  if( (i=find_slot(idfrom=getID()))==(-1) )
  {
    cout << "This student is not our employee!" << endl;
  }
  else
  {
    cout << "New Student ID:" << endl;
    idto = getID();
    if(find_slot(idto)!=(-1))
    {
      cout << "The student already exists." << endl;
    }
    else if((j=find_empty_slot())==(-1))
    {
      cout << "No space for creating a student employee!" << endl;
    }
    else
    {
      emp[j] = emp[i];
      emp[j].id = idto;
      getName(name);
      strcpy(emp[j].name,name);
    }
  }
}

void show_all_student_employees_information()
{
  int i;
  cout << "Salary Table" << endl;
  for(i=0;i<10;i++)
  {
    if(emp[i].id!=0)
      cout << emp[i];
  }
}

void show_student_employee_information()
{
  int i,id;

  id = getID();

  if((i=find_slot(id))==(-1))
  {
    cout << "This student is not our employee!" << endl;
  }
  else
  {    
    cout << emp[i];
  }
  
}


void create_a_new_student_employee()
{
  char name[21];
  int id;
  int i;
  
  if( (i=find_empty_slot())==(-1) )
  {
    cout << "No space for creating a student employee" << endl;
  }
  else
  {
    id = getID();
    getName(name);
    emp[i]=StudentEmployee(id, name);    
    cout << emp[i];
  }
}
