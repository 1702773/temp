#include <string>

using namespace std;
 
class Student
{

  private:
   float homework[10];
   float midterm;
   float final;
   float homeworkaverage;
   float h_A, m_A, f_A;
   
  public:
    
    string SID;
    string name;
    Student();
    ~Student();
    Student(string x, string y);  
    void setHomework(int i, float s);
    void setMidterm(float s);
    void setFinal(float s);
    void setSID(const string id);
    void setName(const string n);
    
    float getHomework(int i);
    float getMidterm();
    float getFinal();
    string getSID();
    string getName();
    
    void setRatio(float h,float m,float f);
    float getHomeworkAverage(int num);
    float getScore();
    void showInfo();
    void showScore();  

};
  
