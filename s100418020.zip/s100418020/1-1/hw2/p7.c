#include <stdio.h>

int main(void)
{

  int x;  
  printf("請輸入數字:\n");
  scanf("%d", &x);
  
  int a=x/50,b=(x-50*a)/20,c=(x-50*a-20*b)/10,d=(x-50*a-20*b-10*c)/5,e=x-50*a-20*b-10*c-5*d;
  
  
  
  
 
    
  printf("50 coins:%d\n",a);
  printf("20 coins:%d\n",b);
  printf("10 coins:%d\n",c);
  printf("5 coins:%d\n",d);
  printf("1 coins:%d\n",e);
  





return 0 ;
}



