#include <stdio.h>
#include <time.h>
int main()
{
int card[51];//代表52張牌
int a;//拿來判斷玩家是否要牌
int color;//判斷花色
int bj,bj2;//判斷是否有A這張牌可以當作1點而不是11

int i,j,s,p1=0,p2=0,temp;//s為這張牌的點數p1為玩家的總點術p2為莊家的總點數
srand((unsigned)time(NULL));
//給52張牌大小
for (i=0;i<52;i++)
card[i]=i;
//洗牌
for (i=0;i<52;i++)
{
j=rand()%52;//以隨機函數取52的餘數拿來當作1~52張隨機一張牌
temp=card[i];
card[i]=card[j];
card[j]=temp;
}

i=0;
a=0;
bj=0;
bj2=0;
//判斷是否還要牌並算現在的點數
while(a==0)
{
s=(card[i]%13)+1;//s為這張牌的點數
//如果是大於10的牌點數為10
if(s>10)
s=10;

//如果牌為任何花色的A則點數為11
if((card[i]==0)||(card[i]==13)||(card[i]==26)||(card[i]==39))
{
s=11;
bj=bj+1;//如果有一張牌為A則打bj這個變數+1當作手牌有一張A可以當作1點
}

  printf("這張牌是:");
  //判斷花色
  color=card[i]/13;
  if(color==0)
  printf("黑桃");
  if(color==1)
  printf("紅心");
  if(color==2)
  printf("方塊");
  if(color==3)
  printf("梅花");

  printf("%d",(card[i]%13)+1);

p1=p1+s;//算出目前的總點數
i++;//i為第i張牌每次都要發下一張所以要+1

//如果玩家點數大於21點並且手上有A則把A當做1點而不是11點
if((p1>21)&&(bj>=1))
{p1=p1-10;
bj--;//bj用來判斷手上有沒有A當做1點如果有一張A當做1點則不會在有A可以拿來當作1點
}
printf("你現在的點數是%d\n",p1);

if (p1>21)
a=1;
else
{
printf("你還要一張牌嗎?輸入0為是1為否\n");
scanf("%d",&a);
}
}

//如果拿到的是A跟任一張大於等於10的牌則為blackjack
if((i==2)&&(p1==21))
printf("Blackjack妳贏得此遊戲\n");
//判斷是否大於21點
else
{
//判斷玩家是否大於21點如果是則輸掉此遊戲
if(p1>21)
printf("你輸了此遊戲\n");
else
{
//如果拿到的種牌數大於等於5張則贏得此遊戲
if(i>4)
printf("恭喜你牌數大於5張而贏得此遊戲\n");
else
{
s=0;

while(p2<16)
{s=(card[i]%13)+1;
if(s>10)
s=10;
//如果牌為任何花色的A則點數為11
if((card[i]==0)||(card[i]==13)||(card[i]==26)||(card[i]==39))
{
s=11;
bj2=bj2+1;//如果有一張牌為A則打bj2這個變數+1當作手牌有一張A可以當作1點
}

//判斷花色
  printf("這張牌是:");
  color=card[i]/13;
  if(color==0)
  printf("黑桃");
  if(color==1)
  printf("紅心");
  if(color==2)
  printf("方塊");
  if(color==3)
  printf("梅花");

  printf("%d",(card[i]%13)+1);

p2=p2+s;//計算目前莊家的總點數
//如果莊家點數大於21並且有A在手上則把A當做1點而不是11點
if((p2>21)&&(bj2>=1))
{p2=p2-10;
bj2--;//bj2用來判斷手上有沒有A當做1點如果有一張A當做1點則不會在有A可以拿來當作1點
}
printf("莊家現在的點數是:%d",p2);
printf("\n");
i++;
}
//判斷莊家點數是否大於21點
if(p2>21)///莊家大於21點則玩家勝利
printf("你贏得此遊戲\n");
else//莊家沒大於21點則比莊家跟玩家誰的點數大
{
if(p1>p2)
printf("你贏得此遊戲\n");
else
printf("你輸了此遊戲\n");
}
}
}
}
return 0;
}
