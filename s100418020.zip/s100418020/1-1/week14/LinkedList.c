#include <stdio.h>
#include <stdlib.h>

#include "LinkedList.h"

Node *first=NULL;
Node *new_node;
Node *temp_node;

int search(int data)
{
  temp_node = first;
   while(temp_node)
    {
     if(temp_node->value == data) return 1;
     temp_node = temp_node->next;
    }
  return 0;
}

void delete( int data)
{
  Node *prev=NULL;
  Node *next=NULL;
  temp_node = first;
   while((temp_node)&&(temp_node->value == data))
    {
     first = temp_node->next;
     free(temp_node);
     temp_node = first;
    }
      while(temp_node)
       {
         prev = temp_node;
         temp_node = temp_node->next;
           while((temp_node)&&(temp_node->value == data))
            {
              next = temp_node->next;
              free(temp_node);
              temp_node = next;
            }
         prev->next = temp_node;
       } 
}


void insert(int data)
{
  new_node = malloc( sizeof(Node) );
  new_node->value = data;
  new_node->next = first;
  first=new_node;
}

void showAllData()
{
  printf("here");
  temp_node = first;
  while((temp_node->next !=NULL)&&(first!=NULL))
  {
    printf("%d->", temp_node->value);
    temp_node = temp_node->next;
  }
  if(temp_node!=NULL)
    printf("%d->NULL\n", temp_node->value);
}

