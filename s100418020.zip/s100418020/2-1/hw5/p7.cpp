#include <iostream>
#include <string>

using namespace std;

struct pizza_data 
{

string name ;
double diameter; 
double weight;

};


int main ()
{

pizza_data pizza;
cout << "Please enter the pizza company: ";
getline(cin,pizza.name);

cout << "Please enter the pizza diameter: ";
cin >> pizza.diameter;

cout << "Please enter the pizza weight: ";
cin >> pizza.weight;

cout << endl;
 
cout << "Pizza company: " << pizza.name << endl;
cout << "Pizza diameter: " << pizza.diameter << endl;
cout << "Pizza weight: " << pizza.weight << endl;

}

