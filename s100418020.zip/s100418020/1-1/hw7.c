#include <stdio.h>

int Fib(int n)
{

if(n>1)
return Fib(n-1)+Fib(n-2);
if(n==1)
return 1;
if(n==0)
return 0;

}

int main(void)
{

int n;
printf("Pleaseenterthevalueofn:");
scanf("%d",&n);
printf("Thevalueofn=%d\n",Fib(n));

}

