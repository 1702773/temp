#include "Student.h"
#include "StudentEmployee.h"

using namespace std;

StudentEmployee::StudentEmployee(const char * n,char *i): Student() 
{
  checkin.h = 0;
  checkin.m = 0;  
  hours.h = 0;
  hours.m = 0;        
  salary = 0;

}

StudentEmployee::StudentEmployee()
{
  checkin.h = 0;
  checkin.m = 0;
  hours.h = 0;
  hours.m = 0;
  salary = 0;
}

void StudentEmployee::showInfo()
{
  cout << name << "(" << id << "), " << hours.h <<":"<< hours.m << ",NT. " << salary  << endl; 
}

void StudentEmployee::checkIn(const Time t)
{
  checkin.h = t.h;
  checkin.m = t.m;
}

void StudentEmployee::checkOut(Time &t)
{
  hours.m = t.m - checkin.m;

  if (hours.m < 0)
  {
    t.h--;
    hours.m += 60;
  }
  
  hours.h += t.h - checkin.h;
  salary = long(hours.h) * 100 + long(float(hours.m)/60 *100);
}

/*void StudentEmployee::add_eight_hours(Time &eight) ////
{
  eight = hours.h + 8; 
}*/



