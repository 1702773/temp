#include <stdio.h>

int main (void)
{

int w,x,y,z,max,min;

printf("Enter four integers: ");
scanf("%d %d %d %d",&w,&x,&y,&z);

max=w;
min=w;

if(x>max) max=x;
else if(x<min) min=x;

if(y>max) max=y;
else if(y<min) min=y;

if(z>max) max=z;
else if(z<min) min=z;

printf("Largest: %d\n",max);
printf("Smallest: %d\n",min);


return 0;
}


