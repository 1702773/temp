#ifndef RestricedStudentEmployee_H_
#define RestricedStudentEmployee_H_
#include <iostream>
#include <string>
#include "Student.h"
#include "StudentEmployee.h"
#include "Time.h"

class RestricedStudentEmployee : public StudentEmployee
{
  public:
      int UBHours;
      long UBSalary;
      
      virtual void showInfo();
      RestricedStudentEmployee(char *n,char *i,int ubh,long ubs );
      RestricedStudentEmployee();
      void checkOut(Time & t);
};

#endif 


