#include <stdio.h>
int main (void)
{
int a,b,c,d;

printf("Enter a fraction: ");
scanf("%d/%d",&a,&b);
c = a;
d = b;
while (a>0 && b>0)
{
  if (a>b)
  a = a % d;
  else
  b = b % d;
}
  if (a == 0)
{
  c = c / b;
  d = d / b;
  printf("In lowest terms: %d/%d\n",c,d);
}
else
{
c = c / a;
d = d / a;
printf("In lowest terms: %d/%d\n",c,d);
}
return 0; 
}

