#include <iostream>
#include <string>

using namespace std;

struct inflatable 
{

char name [50];
float weight;
int calories;

};


int main()
 {
 
 inflatable snake=
  {
   "Mocha Munch",
   2.3,
   350
   
  };

 


cout << "Your snake name is: " << snake.name << endl; 
cout << "weight: " << snake.weight << endl;
cout << "calories: " << snake.calories << endl;    

}





