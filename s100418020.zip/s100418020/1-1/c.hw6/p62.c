#include <stdio.h>

int main (void)
{

int x,y;

printf("Enter two integers: ");
scanf("%d %d",&x,&y);

while(x>0 && y>0)
{

if (x>=y) x= x % y;
else if (x<=y) y= y % x;  

}
    
if (x==0) printf("Greatest common divisor: %d\n",y);
else if (y==0) printf("Greatest common divisor: %d\n",x);                             


return 0;
}

