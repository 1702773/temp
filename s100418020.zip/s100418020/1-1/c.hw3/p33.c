#include <stdio.h>
int main(void)
{
int a,b,c,x,y;

printf("Enter ISBN:");
scanf("%d-%d-%d-%d-%d",&a,&b,&c,&x,&y);

printf("GSI prefix: %d\n",a);
printf("Group identifier: %d\n",b);
printf("Publisher code: %d\n",c);
printf("Item number: %d\n",x);
printf("Check digit: %d\n",y);

return 0;
}





