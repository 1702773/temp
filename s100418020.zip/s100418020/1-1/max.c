#include <stdio.h>


int data[10]={10,30,3,384,45,2,110,355554,45,6};

int max(int i)
{
  int temp;
 
  if(i==1)
    return data[0];
  else
  {
    temp = max(i-1);
  
    if( data[i-1] > temp)
      return data[i-1];
    else
      return temp;
  }
}

int main()
{
//  int n;

//  int i=0;
//  int result =1;
  
  
//  scanf("%d", &n);
  
//  printf("n=%d 1+2+...+n=%d\n", n, sum(n));

  printf("max=%d\n", max(10));  // max(n)= max{ data[0], data[1], ... , data[n-1]}

}
