#include <stdio.h>
#include <stdlib.h>

int main(void)
{
int quit=0;
int data;
int cmd;

while(!quit)
{
printf("1 insert , 2 print , 3 search , 4 quit. \n");
printf("input a commend:");
scanf(" %d",&cmd);

switch(cmd)
{

case 1:
printf("input a value:");
scanf(" %d",&data);
insert(data);
break;

case 2:
PrintTree();
break;

case 3:
printf("input a value to search:");
scanf(" %d",&data);
search(data);
break;

case 4:
quit=1;
break;

}
}
}



