#include <iostream>
#include <iomanip>
#include <climits>

using namespace std;

int main()
{
 double kilometer,liter,gallon,mile,mpg ;

 
 cout << "Enter the kilometer:";
 cin >> kilometer;
 cout << "Enter the gasoline capacity:";
 cin >> liter;
  
 gallon=0.2642*liter ;        //公升轉加倫
 mile=0.6214*kilometer ;     //公里轉英里


 mpg = mile/gallon;
 cout << setprecision(3);
 cout << mpg <<" mpg = " << liter << " L/" << kilometer << "km" << endl;


}


