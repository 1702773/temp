#include <stdio.h>
#include <stdlib.h>

#define BOARD 3  //size
#define FORTHEWIN 3 //win

int board[BOARD][BOARD]={0};
int PrintBoard();
int CheckPlayer(int ,int );
int CheckComputer(int ,int );
int Player();
int Computer();
int CheckWin();
int Checkdir();
int PrintWinner();
int Clear();

  int PrintBoard()
  {
    int i,j;
  

  for(i=0;i<BOARD;i++)
    {
       printf("\t");
        for(j=0;j<BOARD;j++)
        {
         switch(board[i][j])
         {
          case 0:printf(" ");
               break;
          case 1:printf("X");
               break;     
          case 2:printf("O");
               break;  
  
         }
       }
      printf("\n");
   }
}
  

  int Clear()
{
    int i,j;
 for(i=0;i<BOARD;i++)
     {
       for(j=0;j<BOARD;j++)
       {	
        board[i][j]=0;
       }
     }
}
  
  int CheckPlayer(int x,int y)
{
    if(x<1||x>BOARD||y<1||y>BOARD||board[x-1][y-1]!=0)
    {
      return 1;
    }
      return 0;
}

  int CheckComputer(int x,int y)
{
   if(board[x][y]!=0)
   {
     return 1;
   }
     return 0;
}

  int Player()
{
    int x,y;
    printf("Please enter the position you want(1~3,1~3): ");
    scanf("%d,%d",&x,&y);
    while((CheckPlayer(x,y)))
    {
      printf("Please enter the position again(1~3,1~3):");
      scanf("%d,%d",&x,&y);
    }
    board[x-1][y-1]=2;
    printf("Now is player \n");
    PrintBoard();
    return PrintWinner(CheckWin());
}

  int Computer()
{
    int	x,y;
    srand((int)time(0));
    x=(rand()%BOARD);
    y=(rand()%BOARD);
    while((CheckComputer(x,y)));
    board[x][y]=1;
    printf("Now is computer\n");
    PrintBoard();
    return PrintWinner(CheckWin());
}

  int Checkdir(int x,int y,int count,int dirx,int diry)
{
    int tmp;
    
    if(count==FORTHEWIN)
    {
      switch(board[x-1][y-1])
      {
       case 1:return 1;
            break;
       case 2:return 2;
            break;
      }
    }
    tmp=board[x-1][y-1];
    if(tmp==0) return 0;
    if((x+dirx)>BOARD||(x+dirx)<1||(y+diry)>BOARD||(y+diry)<1)return 0;  //out of board?
    if(board[(x+dirx)-1][(y+diry)-1]!=tmp) return 0;   //different?
    if(board[(x+dirx)-1][(y+diry)-1]==tmp)
    {
      count++;
      return Checkdir(x+dirx,y+diry,count,dirx,diry);
    }
}

  int CheckWin()
{
    int x,y,k,count=0,tmp;
    int dirx[8]={-1,-1,-1,0,1,1,1,0};//dir=Direction
    int diry[8]={-1,0,1,1,1,0,-1,-1};

    for(x=1;x<=3;x++)
    {
      for(y=1;y<=3;y++)
      {
        for(k=0;k<8;k++)
        {
        count=1;
        tmp=(Checkdir(x,y,count,dirx[k],diry[k]));
        if(tmp!=0)
        {
          return tmp;
        }
      }
    }
  }
}

  int PrintWinner(int x)
{
  if(x==1)printf("Computer win the game!!\n");
  if(x==2)printf("You win the game!!\n");
  if(x!=0) return 1;//jump out loop
}





  int	main(void)
{
  char select;
  while(1)
  {
    Clear();
    while(1)
    {
      if(Player()==1)
      break;
      
      if(Computer()==1)
      break;
    }

scanf("%c",&select);		//absorbthe'\n'=getchar();
    }
}


