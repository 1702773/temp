#include <iostream>
#include <string>

using namespace std;

struct CandyBar 
{

 string name;
 float weight;
 int price;

};

int main() 
{
 
 CandyBar *p = new CandyBar[3];

 p[0].name = "Blue candy";
 p[0].weight = 1.5;
 p[0].price = 35;
 p[1].name = "Red candy";
 p[1].weight = 1.7;
 p[1].price = 35;
 p[2].name= "green candy";
 p[2].weight=0.5;
 p[2].price=10;

 cout << "The commodity name: " << p[0].name << endl;
 cout << "weight: " << p[0].weight << endl;
 cout << "price: " << p[0].price << endl;
 cout << endl;     

 cout << "The commodity name: " << p[1].name << endl;
 cout << "weight: " << p[1].weight << endl;
 cout << "price: " << p[1].price << endl;
 cout << endl;
          
 cout << "The commodity name: " << p[2].name << endl;
 cout << "weight: " << p[2].weight << endl;
 cout << "price: " << p[2].price << endl;          
 cout << endl;

 delete [] p;
}


