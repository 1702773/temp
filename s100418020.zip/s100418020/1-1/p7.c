#include <stdio.h>

int main(void)
{
  int a,b,c,d;
  printf("請輸入數字:\n");
  d=a-50*c;
  scanf("%d",&c);
  
  
  
  printf("50 coins:\n");
  printf("20 coins:\n");
  printf("10 coins:\n");
  printf("1 coins:\n");
  
  
  
return 0;
}



