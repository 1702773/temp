#include <iostream>
#include <cmath>
#include <climits>

using namespace std;
int main()
{
long long int x;
long int d,h,m,s;

 cout<<"Enter the number of seconds: ";
 cin >> x;

 d=x/86400;
 h=(x%86400)/3600;
 m=(x-d*86400-h*3600)/60; 
 s=x-d*86400-h*3600-m*60;
 
 cout<< x <<" seconds = "<< d <<" days, "
     << h <<" hours, "<< m <<" minutes, "<< s <<" seconds"<< endl;  



}





