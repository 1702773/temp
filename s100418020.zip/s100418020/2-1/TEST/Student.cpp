#include "Student.h"

using namespace std;

Student::Student()
{
  strcpy(name,"empty");
  strcpy(id,"empty");
  
}

void Student::showInfo()
{
  cout << name << "(" << id  << ")" << endl ;
}



