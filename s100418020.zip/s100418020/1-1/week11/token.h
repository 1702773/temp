
void getUserInputString();
int hasNextToken();
void getAToken();


/*char str[80]=" ";
char token[80];
int _j=0; */
