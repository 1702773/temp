#include <iostream>
#include <cmath>

using namespace std;
double f(double),c;

int main ()
{

cout << "Please enter a Celsius value:";
cin >> c; 
cout << c <<" degrees Celsius is "<< f(c) <<" degrees Fahrenheit." << endl ;

}

double f(double c)
{

c = 1.8*c+32.0 ;
return c;

}

