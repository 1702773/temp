#include <iostream>
#include <string>
#include "Student.h"

using namespace std;

  Student::Student(string SID_A, string name_A)
  {
    SID = SID_A;
    name = name_A;
    for(int i=0;i<10;i++)
    {
      homework[i] = 0.0;
    }
    midterm = 0.0;
    final = 0.0;
  }

  Student::Student()
  {
    int x;
    SID = "unknow";
    name = "unknow";
    for(int x=0;x<10;x++)
    {
    homework[x] = 0.0;
    }
    midterm = 0.0;
    final = 0.0;    
  }
  
  Student::~Student()
  {
    cout << "Student " << SID << " / " << name 
         << " has been deleted."<< endl;
  
  }

  void Student::setHomework(int i, float s)
  {
    homework[i]=s;
  
  }

  void Student::setMidterm(float s)
  {
    midterm = s;
  }

  void Student::setFinal(float s)
  {
    final = s;
  }

  void Student::setSID(const string id)
  {
    SID = id;
  }
  
  void Student::setName(const string n)
  {
    name = n;
  }

  void Student::setRatio(float h, float m, float f)
  {
    h_A = h;
    m_A = m;
    f_A =f;
  }  
  
    
  float Student::getHomeworkAverage(int num)
  {
    int i, j;
    float temps[10], temp;
    for(i=0;i<10;i++)
    temps[i] = homework[i];
    for(i=0;i<10;i++)
    {
      for(j=0;j<9;j++)
      {
        if(temps[j]<temps[j+1])	
        {
          temp = temps[j];
          temps[j] = temps[j+1];
          temps[j+1] = temp;
        }
      }
    }
    
    temp = 0;
    for(i=0;i<num;i++)
    {
      temp += temps[i];
    }
    
    homeworkaverage = temp/num;
    return homeworkaverage;
  }
  
  void Student::showInfo()
  {
    cout << getName() << " ( " << getSID() << " ) " << endl;
  }
  
  void Student::showScore()
  {
    cout << getName() << " ( " << getSID() << " ) " << getScore() << endl; 
  }
  
  float Student::getHomework(int i)
  {
    return homework[i];
  }
  
  float Student::getMidterm()
  {
    return midterm;
  }
  
  float Student::getFinal()
  {
    return final;
  }
  
  string Student::getSID()
  {
    return SID;
  } 
  
  string Student::getName()
  {
    return name; 
  }
  
  float Student::getScore()
  {
    return (homeworkaverage * h_A+ midterm * m_A+ final * f_A);
  }



