#include <iostream>

using namespace std ;
int f(),s() ;
 
int main()
{
 
 f();
 f();
 s();
 s();

}

int f()
{
 cout << "Three blind mice" << endl;
}

int s()
{
 cout << "See how they run" << endl;
}
