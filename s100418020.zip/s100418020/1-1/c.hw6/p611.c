#include <stdio.h>
int main (void)
{
int n;
float i,c,b,d,e,f;
printf("請輸入n的值: ");
scanf("%d",&n);
c = 2;
i = 2;
d = 2;
e = 1;
f = 0;
b = 2;
if (n >= i)
  {
  while (i <= n)
  {
    e = e * d;
    f = 1 / e;
    b = b + f;
    i++;
    d++;
  }
  printf("e = %f\n",b);
  }
else
  {
  printf("e = %f\n",c);
  }
return 0;
}
