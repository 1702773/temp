#include <stdio.h>
int main(void)
{
int m1,m2,d1,d2,y1,y2;

printf("Please input a date(YYYY/MM/DD):");
scanf("%4d/%d/%2d",&y1,&m1,&d1);

printf("Please input another date(YYYY/MM/DD):");
scanf("%4d/%d/%2d",&y2,&m2,&d2);

if (y1==y2)
 if (m1==m2)
  if (d1>d2)
  printf("%4d/%1d/%2d is later than %4d/%d/%2d\n",y1,m1,d1,y2,m2,d2);
  
  else printf("%4d/%d/%2d is later than %4d/%d/%2d\n",y2,m2,d2,y1,m1,d1);

 else if (m1>m2) printf("%4d/%d/%2d is later than %4d/%d/%2d\n",y1,m1,d1,y2,m2,d2);
     else printf("%4d/%d/%2d is later than %4d/%d/%2d\n",y2,m2,d2,y1,m1,d1);

else if (y1>y2) printf("%4d/%d/%2d is later than %4d/%d/%2d\n",y1,m1,d1,y2,m2,d2);
     else printf("%4d/%d/%2d is later than %4d/%d/%2d\n",y2,m2,d2,y1,m1,d1);

return 0;

}
