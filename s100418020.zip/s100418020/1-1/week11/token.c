#include <stdio.h>

#include "token.h"

char str[80]=" ";
char token[80];
int _j=0;

void getUserInputString()
{
  scanf(" %[^\n]", str);
}

int hasNextToken()
{
  return (str[_j]=='\0'? 0: 1);
}


void getAToken()
{
  int i=0;
  while((str[_j]!=' ')&&(str[_j]!='\0')&&(str[_j]!='\n'))
  //while((str[_j]!=' ')&&(_j!=80))
  {
    token[i]=str[_j];
    i++;
    _j++;
  }
  token[i]='\0';
  _j++;
}

/*
int main()
{
  printf("Please input a string:\n");
  getUserInputString();  


  while(hasNextToken()==1)
  {
    getAToken();
    printf("%s\n", token);
  }
  
  
}*/


