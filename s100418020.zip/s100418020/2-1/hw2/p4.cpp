#include <iostream>

using namespace std;
int carrots,x(int);

int main()
{
cout << "Enter your age:" ;
cin >> carrots;

cout << "your age in month is "<< x(carrots) <<"."<< endl;
}

int x(int carrots)
{
carrots = carrots * 12;
return carrots;
}

