#include <stdio.h>
#include <stdlib.h>
#include "tree.h"

void AfterInsert(int data , Leaf_node *temp_leaf);
void AfterPrintTree(Leaf_node *temp_leaf);
void AfterSearch(int data,Leaf_node *temp_leaf);

Leaf_node *root=NULL;
Leaf_node *new_leaf;
int RootOrNotRoot=1;


void insert(int data)
{
if(RootOrNotRoot==1)
{
root = malloc( sizeof(Leaf_node) );
root->value = data;
RootOrNotRoot=0;
return;
}
else
AfterInsert(data, root);
}


void AfterInsert(int data, Leaf_node *temp_leaf )
{
if(data < temp_leaf->value)
{
if(temp_leaf->left == NULL)
{
new_leaf = malloc( sizeof(Leaf_node) );
new_leaf->value = data;
temp_leaf->left = new_leaf;
}
else
AfterInsert(data,temp_leaf->left);
}
else
if(temp_leaf->right == NULL)
{
new_leaf = malloc( sizeof(Leaf_node) );
new_leaf->value = data;
temp_leaf->right = new_leaf;
}
else
AfterInsert(data,temp_leaf->right);
}


void PrintTree()
{
if(root == NULL)
{
printf("you can't print before you insert something.\n");
return;
}
AfterPrintTree(root);
printf("\n");
}


void AfterPrintTree(Leaf_node *temp_leaf)
{
printf("(");

if(temp_leaf->left != NULL)
AfterPrintTree(temp_leaf->left);
else
printf("e");
printf(",%d",temp_leaf->value);
if(temp_leaf->right != NULL)
AfterPrintTree(temp_leaf->right);
else
printf("e");

printf(")");
}


void search(int data)
{
if(root == NULL)
{
printf("Sorry,you can't search before you insert something !\n");
return;
}
else
AfterSearch(data,root);
}


void AfterSearch(int data,Leaf_node *temp_leaf)
{
if( temp_leaf != NULL)
{
if( (temp_leaf->value) == data)
{
printf("*** IT EXIST ***\n");
return;
}
else
{
if(data < (temp_leaf->value ))
{
AfterSearch(data,temp_leaf->left);
}
else
AfterSearch(data,temp_leaf->right);
}
}
else
{
printf("***IT DOESN'T EXIST!\n");
return;
}
}



