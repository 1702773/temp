#include <stdio.h>
int main(void)
{
int 



return 0;
}

