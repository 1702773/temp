#include <stdio.h>
int main(void)
{
int i,w=0,j,x=1,k,y=3,a,b=6,z;

for(i=1;i<=5;i++)
{
  for(i=1;i<=w;i++){printf(" ");}
  for(j=1;j<=x;j++){printf("*");}
  
printf("\n");

w++;
x++;
}

for(k=1;k<=4;k++)
{
  for(z=1;z<=y;z++){printf(" ");}
  for(a=1;a<=b;a++){printf("*");}

printf("\n");
 
y--; 
b++;
}

return 0;
}

