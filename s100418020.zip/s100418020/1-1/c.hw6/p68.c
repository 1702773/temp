#include <stdio.h>
int main (void)
{
int a , b , i , j;
printf("Enter number of days in month: ");
scanf("%d",&a);
printf("Enter starting day of the week (1=Sun, 7=Sat): ");
scanf("%d",&b);
printf("\n");
if (b>7)
  {
  printf("Error a number.\n");
  }
  else
  {
  j = 7;
  switch (b)
  {
  case 2 :  printf("   ");                 break;
  case 3 :  printf("      ");              break;
  case 4 :  printf("         ");           break;
  case 5 :  printf("            ");        break;
  case 6 :  printf("               ");     break;
  case 7 :  printf("                  ");  break;
  }
  b = b - 1;
  for (i = 1; i <= a ; i++)
  {
  b++;
  if ( b == j )
  {
  b = 0;
  printf("%2d \n",i);
  }
  else
  printf("%2d ",i);
  }
  printf("\n");
  }
  return 0;
}
