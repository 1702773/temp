
struct node
{
  int value;
  struct node *next;
};

typedef struct node LinkedList;

typedef struct node Node;

int search(int data); // 0 for false , 1 for true

void delete(int data);

void insert(int data);
void showAllData();



