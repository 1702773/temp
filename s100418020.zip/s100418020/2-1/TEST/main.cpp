#include <iostream>
#include <string>
#include "Student.h"
#include "StudentEmployee.h"
#include "RestricedStudentEmployee.h"

using namespace std;

int main()
{
 
  StudentEmployee emp[11];
  RestricedStudentEmployee remp[11]; 
 
  int q = 0;
  int x = 0; 	//選擇那一筆資料
  int y = 0; 	//存放(建立)了幾筆資料
  string word;
  
  while(q!=1)
  {
    a1:
    int k ;
    
    if (x==0)  //如果資料為空 則印出 empty
    {
      cout << "<empty>" ;
    }
    
    else  // strcpy 為比較的功能 strcmp(x,y) 若 x = y 則會 =0   
    { 	  
        if(strcmp(emp[x].id,"empty") !=0 ) // emp 不是空的 就印出emp的資料
        {
           cout << "<" << emp[x].name << "," << emp[x].id << ">" ; 
        }
        
        else  //emp 是空的 那就印 remp 的資料
        {
           cout << "<" << remp[x].name << "," << remp[x].id << ">" ;   
        }
    
    }  
    
    cin >> word ; // 不能用switch 因為是 char 只能讀字元
    
    
    
/**/    if( word == "new" )
        {
          char name[20];
          char id[20];
          char select;  // 選擇是正職員工(Res..) OR 工讀生(Stu..)
          int hour;
          long salary;
      
      
          cout << "Adding a new student employee ..." << endl;
          cout << "Name:" ;
          cin.get();
          cin.getline(name,20);
            
          cout << "ID: " ;
          cin >> id ;
          
          
          for (k=1;k<11;k++)  
          {
              if ( strcmp(emp[k].id,id) == 0)
              {
                cout << "Error: Student exists." << endl; 
                cout << "Aborted." << endl;
                goto a1;
              }
            
              if ( strcmp(remp[k].id,id) == 0)
              {
                cout << "Error: Student exists." << endl; 
                cout << "Aborted." << endl;
                goto a1;
              }
          }	
      
          cout << "Restricted(y/n)?" ;
          cin >> select ;
  
          if ( select == 'y' )     //是否為工讀生 y → 正職 (Res remp)  
          {	
            cout << "Upper Bound of the Working Hours: " ;
            cin >> hour ;
            cout << "Salary: " ;
            cin >> salary ;
            cout << "Done." << endl;  
      
            y++;
            x = y;
       
            strcpy(remp[x].name,name); // strcpy 是把後面的值 複製給前面
            strcpy(remp[x].id,id);
            remp[x].UBHours = hour ;
            remp[x].UBSalary = salary;
            remp[x].hours.h = 0 ;   
            remp[x].hours.m = 0 ;
            remp[x].salary = 0;
          }
      
          else if ( select == 'n')  // n → 工讀 (Stu emp)
          {	
            cout << "Done." << endl;
       
            y++;
            x = y ;
        
            strcpy(emp[x].name,name);
            strcpy(emp[x].id,id);
            emp[x].hours.h = 0 ;
            emp[x].hours.m = 0;
            emp[x].salary = 0 ;
          }
        } // end of new
    
/**/	else if( word == "select" )       
        {
          char data[20];
          int isFound = 0 ;
            
          cout << "Selecting a student ..." << endl;
          cout << "Name/ID: " ;
          cin >> data;
      
          for ( k=1 ; k<11 ; k++)
          {
              if ( (strcmp(emp[k].name,data) == 0) || (strcmp(emp[k].id ,data) == 0) )
              {
                cout << emp[k].name << " (" << emp[k].id << ") is found." << endl <<  "Done."  << endl ;
                isFound = 1;
                x = k ;
                   
                break;
              }	        
       
              else if ( (strcmp(remp[k].name,data) == 0) || (strcmp(remp[k].id ,data) == 0) )       
              {
                cout << remp[k].name << " (" << remp[k].id << ") is found." << endl <<  "Done."  << endl ; 
                isFound = 1;
                x = k ;
               
                break;
              }
          }
      
          if (isFound == 0) 
          {
            cout << "Error: Student not found." << endl << "Aborted" << endl ;
          }
          else
          
            x = k ; 
           
        }// end of select
/**/	else if( word == "unselect") ////  finalexam   ////
        {
           x = 0;
              
           if( strcmp(emp[x].name,"empty")!= 0 ) //x有值
           {
             strcpy(emp[x].name,"empty");
           }
           else if( strcmp(remp[x].name,"empty")!= 0 )  
           {
             strcpy(remp[x].name,"empty");
           }
           
           strcpy(emp[x].name,"empty");
                                    
        } // end of unselect
                                           
/**/    else if( word == "delete" )  
        {
          char input ;
      
          if ( x == 0 )
          {
            cout << "Error: There is no selected student." << endl << "Aborted" << endl ;
          }
        
          else // x!=0
          {
            cout << "Deleting s student ..." << endl;
            cout << "Are you sure(y/n)?" ;
            cin >> input ;
            
              if( input == 'n')
              {
                cout << "Aborted." << endl ;
              }
          
              else if ( input == 'y') // input =='y'  
              {
                while ( x <= y  ) //成立才執行
                {
                  emp[x]=emp[x+1];   // 將 y 資料往前移
                  remp[x]=remp[x+1];
                  x++ ;
                }
           
                x = 0;
                y-- ;
                cout << "Done." << endl ;
              }  
          }
          
        } // end of delete
    
/**/    else if( word == "checkin" ) 
        {	
       
          if ( x == 0 )
          {
            cout << "Error: There is no selected student." << endl ;
            cout << "Aborted." << endl; 
          }
        
          else 
          {
            Time t;
            int h,m;
            
            if ( strcmp(emp[x].name,"empty") != 0 ) //比較 remp & emp 哪一個 checkin
            {
              if ( (emp[x].checkin.h  == 0) && (emp[x].checkin.m == 0 )   ) //h.m 都沒有被更改過 
              {
                cout << " Time (hh:mm)? " ;
                scanf("%2d:%2d", &h,&m );
                t = Time(h,m);
                emp[x].checkin = t;
              }
              
              else
              {
                cout << "Error : Already checked in." << endl << "Aborted." << endl;
              }
            }
            
            else
            {
              if ( (remp[x].checkin.h  == 0) && (remp[x].checkin.m == 0 )   )
              {
                cout << " Time (hh:mm)? " ;
                scanf("%2d:%2d", &h,&m );
                t = Time(h,m);
                remp[x].checkin = t;
              }
              
              else
              {
                cout << "Error : Alreafy checked in." << endl << "Aborted." << endl;
              }
            }

            cout << "Done" << endl ;    
          
          }//end of else
            
    
        }// end of checkin
/**/	else if( word == "8hrs")  ////  finalexam   ////
        {
          if( strcmp(emp[x].name,"empty")== 0 && strcmp(remp[x].name,"empty")== 0 )
          {
            cout << "Error: There is no selected student." << endl  << "Aborted." << endl;
          }
                                              
        }//end of 8hrs    
/**/    else if( word == "checkout" ) 
        {

           if ( x == 0 ) //判斷有沒有選擇資料
           {
             cout << "Error: There is no selected student." << endl ;
             cout << "Aborted." << endl;
           }
           
           else
           {
             Time t;
             int h , m;
        
             //判斷有沒有CHECKIN IF有 才做以下事情
             if ( (emp[x].checkin.h !=0) || (emp[x].checkin.m != 0 ) || (remp[x].checkin.h !=0) || (remp[x].checkin.m != 0 ))
             {

               cout << " Time (hh:mm)? " ;
               scanf("%2d:%2d", &h,&m );
               t = Time(h,m);
                  
               if(strcmp(emp[x].name,"empty") != 0)
               {	
                 if((t.h * 60 + t.m) > (emp[x].checkin.h*60 + emp[x].checkin.m))
                 {
                   emp[x].checkOut(t);
                   emp[x].checkin.h = emp[x].checkin.m = 0; 
                   cout << "Done" << endl ;
                 }
           
                 else
                 {
                   cout << "Error: Check-out time earlier than the check-in time." << endl << "Aborted." << endl;
                 }             
               }
        
               else
               {
                 if((t.h * 60 + t.m) > (remp[x].checkin.h * 60 + remp[x].checkin.m))
                 {
                   remp[x].checkOut(t);
                   remp[x].checkin.h = remp[x].checkin.m = 0;
                 }
           
                 else
                 {
                   cout << "Error: Check-out time earlier than the check-in time." << endl << "Aborted." << endl;
                 }
               }
             }
           }
        } //end of checkout
/**/	else if( word == "show")   ////  finalexam   ////
        {
           if ( strcmp(emp[x].name,"empty")== 0)
           {
             cout << "There is no selected student." << endl  << "Aborted." << endl;
           }
           else if( strcmp(remp[x].name,"empty")== 0 )
           {
             cout << "There is no selected student." << endl  << "Aborted." << endl;
           }
           
           if( strcmp(emp[x].name,"empty")!= 0 ) //x有值 
           {
             emp[x].showInfo();
           }
           else if( strcmp(remp[x].name,"empty")!= 0 )
           {
             remp[x].showInfo();
           }
                                                                                                       
        } // end of show    
/**/    else if( word == "showall") 
        {
          for ( k=1; k<=y ; k++ )
          {
            if ( strcmp( emp[k].id,"empty") != 0)
            {
              emp[k].showInfo();  
            }  
        
            else 
            {
              remp[k].showInfo();
            }
      
            cout << "Done." << endl;
          }    
        } // end of showall
    
/**/    else if( word == "quit" )
        {
          q = 1;
          cout << "Bye." << endl;    
        }//end of quit
    
    
  } //end of while

}



  
  
  
  
  





