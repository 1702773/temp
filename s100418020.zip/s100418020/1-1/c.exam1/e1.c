#include <stdio.h>

int main (void)
{
float a;
int max,min,i,x;

if(i=1) printf("Enter the %dst number:\n",i);

else if(i=2) printf("Enter the %dnd number:\n",i);

else if(i=3) printf("Enter the %drd number:\n",i);

else if(i=4) 
i++;
i<=10;

printf("Enter the %dth number:\n",i);


while (x != 0)
{

if (max<x) max=x; 
printf("The largest number is %d\n",max);

else if (min>x) min=x; 
printf("The smallest number is %d\n",min);


}


//printf("The average number is %g\n",a);

return 0;

}

