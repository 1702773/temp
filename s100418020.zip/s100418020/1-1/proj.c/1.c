#include <stdio.h>
int main (void)
{
int a,i,j,k;

for (i==4,j==1;i>0,j<=7;i--,j+=2) 
{
for (k==1;k>=4;k++){printf(" ");}
for (j==0,j<=7;j+=2){printf("*");}

//if (i==4) printf("    ");
//else if (i==3) printf("   ");
//else if (i==2) printf("  ");
//else if (i==1) printf(" ");

//printf("*\n");
}




return 0;
}
