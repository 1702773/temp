#include <stdio.h>


int main (void)
{
int a , b , c;
printf("請輸入一個數: ");
scanf("%d",&a);
printf("1 ~ %d 所有的偶數平方為: \n",a);
while (c<a)
{
  b = b + 2;
  c = b * b;
if (c<=a)
  printf("%d\n",c);
}


return 0;
}

