#include <stdio.h>


int sum(int n)
{
  if(n>1)
    return n + sum(n-1);
  else
    return 1;
}


int main()
{
  int n;

  int i=0;
  int result =1;
  
  
  scanf("%d", &n);
  
  printf("n=%d 1+2+...+n=%d\n", n, sum(n));
}
