#include<iostream>

int main()
{
using namespace std;
cout<<"Hello world!";
cout<<endl;

return 0;
} 

