#ifndef Time_H_
#define Time_H_
#include <iostream>

class Time 
{
  public :
      int h,m ;
      Time();
      Time( int sh , int sm );      
      void operator= (const Time & t);
};

#endif

