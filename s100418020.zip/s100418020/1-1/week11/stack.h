
#define StackSize 10

int data[StackSize];
int num;

void stack_initial();
int push(int);
int pop();
void stack_show();

