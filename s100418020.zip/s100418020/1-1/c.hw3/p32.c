#include <stdio.h>
int main (void)
{
  int a,dd,mm,yyyy;
  float b;
  printf("Enter item number:");
  scanf("%d",&a);
  
  printf("Enter unit price:");
  scanf("%f",&b);
  
  printf("Enter purchase date:");
  scanf("%d/%d/%d",&dd,&mm,&yyyy); 
  
  printf("Item\t Unit\t\t Purchase\n");
  printf("\t price\t\t date\n");
  
  printf("%3d\t $%2.2f\t\t %2.2d/%2.2d/%4d\n",a,b,dd,mm,yyyy);  


return 0;
}





