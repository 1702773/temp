#include <stdio.h> 
#include <stdlib.h>
#include <string.h>


#include "stack.h"
#include "token.h"

extern char token[80];
extern char str[];
int main(void)
{

  int iNum1=0, iNum2=0;
  stack_initial();
  printf("Please in a RPN-string:");
  getUserInputString();
  while(hasNextToken())
 
  {
      getAToken();
        switch(token[0])
        {
         case '+':
          iNum1=pop();iNum2=pop();
          push(iNum2+iNum1);
         break;
         case '-':
          if(strlen(token)>1)
           push(atoi(token));
           else
           {
            iNum1=pop();iNum2=pop();
            push(iNum2-iNum1);
           }
         break;
         case '*':
          iNum1=pop();iNum2=pop();
          push(iNum2*iNum1);
         break;
         case '/':
          iNum1=pop();iNum2=pop();
          push(iNum2/iNum1);
         break;
          default:
          push(atoi(token));
        }
       }
       printf("%d\n", pop());                                                                                                                                          printf("%s\n", str);

 return EXIT_SUCCESS;

}

