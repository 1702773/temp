#include <iostream>
//#include <string>
#include "studentEmployee.h"

std::ostream & operator<< (std::ostream & os, StudentEmployee & s)
{
int i;
i = int (s.salary);
std::cout << "(" << s.id << "}" << s.name << "Working Hours= " << int(s.wHours/1) << ":" << (int(s.wHours*100)%100)*6/10 << "Salary=NTD$" << i ;
}

void StudentEmployee::operator= (Time & t)
{
checkin.h = t.h;
checkin.m = t.m;
}

StudentEmployee::StudentEmployee(int ids, const char * names)
{
id = ids;
strcpy(name,names);
}

StudentEmployee::StudentEmployee()
{
id = 0;
strcpy(name,"Unknowen");
wHours = 0.0;
checkin.totletime_m = 0;
checkin.totletime_h = 0;
salary = 0.0;
}

void StudentEmployee::operator= (const StudentEmployee & s)
{
id = s.id;
strcpy(name,s.name);
wHours = s.wHours ;
checkin.totletime_h = s.checkin.totletime_h;
checkin.totletime_m = s.checkin.totletime_m;
}

StudentEmployee::~StudentEmployee()
{
}


