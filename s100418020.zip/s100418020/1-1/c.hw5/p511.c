#include <stdio.h>

int main (void)

{
int x,y;

printf("Enter a two-digit number:");
scanf("%1d%1d",&x,&y);

if (x==0 && y==0) printf("You entered the number zero\n");
else if (x==0 && y==1) printf("You entered the number one\n");
else if (x==0 && y==2) printf("You entered the number two\n");
else if (x==0 && y==3) printf("You entered the number three\n");
else if (x==0 && y==4) printf("You entered the number four\n");
else if (x==0 && y==5) printf("You entered the number five\n");
else if (x==0 && y==6) printf("You entered the number six\n");
else if (x==0 && y==7) printf("You entered the number seven\n");
else if (x==0 && y==8) printf("You entered the number eight\n");
else if (x==0 && y==9) printf("You entered the number nine\n");
 
if (x==1 && y==1) printf("You entered the number eleven\n");
else if (x==1 && y==2) printf("You entered the number twelve\n");
else if (x==1 && y==3) printf("You entered the number thirteen\n"); 
else if (x==1 && y==4) printf("You entered the number fourteen\n");
else if (x==1 && y==5) printf("You entered the number fifteen\n");
else if (x==1 && y==6) printf("You entered the number sixteen\n");
else if (x==1 && y==7) printf("You entered the number seventeen\n");
else if (x==1 && y==8) printf("You entered the number eighteen\n");
else if (x==1 && y==9) printf("You entered the number ninteen\n");

if (x==2 && y==0) printf("You entered the number twenty\n");
else if (x==2 && y==1) printf("You entered the number twenty-one\n");
else if (x==2 && y==2) printf("You entered the number twenty-two\n");
else if (x==2 && y==3) printf("You entered the number twenty-three\n");
else if (x==2 && y==4) printf("You entered the number twenty-four\n");
else if (x==2 && y==5) printf("You entered the number twenty-five\n");
else if (x==2 && y==6) printf("You entered the number twenty-six\n");
else if (x==2 && y==7) printf("You entered the number twenty-seven\n");
else if (x==2 && y==8) printf("You entered the number twenty-eight\n");
else if (x==2 && y==9) printf("You entered the number twenty-nine\n");

if (x==3 && y==0) printf("You entered the number thrity\n");
else if (x==3 && y==1) printf("You entered the number thrity-one\n");
else if (x==3 && y==2) printf("You entered the number thrity-two\n");
else if (x==3 && y==3) printf("You entered the number thrity-three\n");
else if (x==3 && y==4) printf("You entered the number thrity-four\n");
else if (x==3 && y==5) printf("You entered the number thrity-five\n");
else if (x==3 && y==6) printf("You entered the number thrity-six\n");
else if (x==3 && y==7) printf("You entered the number thrity-seven\n");
else if (x==3 && y==8) printf("You entered the number thrity-eight\n");
else if (x==3 && y==9) printf("You entered the number thrity-nine\n");

if (x==4 && y==0) printf("You entered the number forty\n");
else if (x==4 && y==1) printf("You entered the number forty-one\n");
else if (x==4 && y==2) printf("You entered the number forty-two\n");
else if (x==4 && y==3) printf("You entered the number forty-three\n");
else if (x==4 && y==4) printf("You entered the number forty-four\n");
else if (x==4 && y==5) printf("You entered the number forty-five\n");
else if (x==4 && y==6) printf("You entered the number forty-six\n");
else if (x==4 && y==7) printf("You entered the number forty-seven\n");
else if (x==4 && y==8) printf("You entered the number forty-eight\n");
else if (x==4 && y==9) printf("You entered the number forty-nine\n");

if (x==5 && y==0) printf("You entered the number fifty\n");
else if (x==5 && y==1) printf("You entered the number fifty-one\n");
else if (x==5 && y==2) printf("You entered the number fifty-two\n");
else if (x==5 && y==3) printf("You entered the number fifty-three\n");
else if (x==5 && y==4) printf("You entered the number fifty-four\n");
else if (x==5 && y==5) printf("You entered the number fifty-five\n");
else if (x==5 && y==6) printf("You entered the number fifty-six\n");
else if (x==5 && y==7) printf("You entered the number fifty-seven\n");
else if (x==5 && y==8) printf("You entered the number fifty-eight\n");
else if (x==5 && y==9) printf("You entered the number fifty-nine\n");

if (x==6 && y==0) printf("You entered the number sixty\n");
else if (x==6 && y==1) printf("You entered the number sixty-one\n");
else if (x==6 && y==2) printf("You entered the number sixty-two\n");
else if (x==6 && y==3) printf("You entered the number sixty-three\n");
else if (x==6 && y==4) printf("You entered the number sixty-four\n");
else if (x==6 && y==5) printf("You entered the number sixty-five\n");
else if (x==6 && y==6) printf("You entered the number sixty-six\n");
else if (x==6 && y==7) printf("You entered the number sixty-seven\n");
else if (x==6 && y==8) printf("You entered the number sixty-eight\n");
else if (x==6 && y==9) printf("You entered the number sixty-nine\n");

if (x==7 && y==0) printf("You entered the number seventy\n");
else if (x==7 && y==1) printf("You entered the number seventy-one\n");
else if (x==7 && y==2) printf("You entered the number seventy-two\n");
else if (x==7 && y==3) printf("You entered the number seventy-three\n");
else if (x==7 && y==4) printf("You entered the number seventy-four\n");
else if (x==7 && y==5) printf("You entered the number seventy-five\n");
else if (x==7 && y==6) printf("You entered the number seventy-six\n");
else if (x==7 && y==7) printf("You entered the number seventy-seven\n");
else if (x==7 && y==8) printf("You entered the number seventy-eight\n");
else if (x==7 && y==9) printf("You entered the number seventy-nine\n");

if (x==8 && y==0) printf("You entered the number eighty\n");
else if (x==8 && y==1) printf("You entered the number eighty-one\n");
else if (x==8 && y==2) printf("You entered the number eighty-two\n");
else if (x==8 && y==3) printf("You entered the number eighty-three\n");
else if (x==8 && y==4) printf("You entered the number eighty-four\n");
else if (x==8 && y==5) printf("You entered the number eighty-five\n");
else if (x==8 && y==6) printf("You entered the number eighty-six\n");
else if (x==8 && y==7) printf("You entered the number eighty-seven\n");
else if (x==8 && y==8) printf("You entered the number eighty-eight\n");
else if (x==8 && y==9) printf("You entered the number eighty-nine\n");

if (x==9 && y==0) printf("You entered the number ninety\n");
else if (x==9 && y==1) printf("You entered the number ninety-one\n");
else if (x==9 && y==2) printf("You entered the number ninety-two\n");
else if (x==9 && y==3) printf("You entered the number ninety-three\n");
else if (x==9 && y==4) printf("You entered the number ninety-four\n");
else if (x==9 && y==5) printf("You entered the number ninety-five\n");
else if (x==9 && y==6) printf("You entered the number ninety-six\n");
else if (x==9 && y==7) printf("You entered the number ninety-seven\n");
else if (x==9 && y==8) printf("You entered the number ninety-eight\n");
else if (x==9 && y==9) printf("You entered the number ninety-nine\n");



return 0;
}

