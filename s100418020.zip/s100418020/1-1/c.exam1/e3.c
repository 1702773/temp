#include <stdio.h>
int main (void)
{
int i,j;

for (i=1;i<4;i++)
 for(j=1;j<10;j++)
 printf("%d x %d = %d\n",i,j,i*j);

for (i=4;i<7;i++)
 for(j=1;j<10;j++)
 printf("%d x %d = %d\n",i,j,i*j);

for (i=7;i<10;i++)
 for(j=1;j<10;j++)
 printf("%d x %d = %d\n",i,j,i*j);
  

return 0;
}
