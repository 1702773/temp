#include <iostream>

using namespace std;

int t_2(int x,int y);

int main()
{
  int a,b;
  cout << "Please enter two numbers: ";
  cin >> a >> b;
  cout << "Your answer is : " << t_2(a,b) << endl << endl;
  return 0;
}

int t_2(int x,int y)
{
  if( y==0 )
    return x;
  else  
    return t_2(y,x%y);
}
           
