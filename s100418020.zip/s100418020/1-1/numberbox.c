#include <stdio.h> 
#include <stdlib.h>

#define StackSize 10

void initial(int [], int *);
char getUserCommand();
int getData();
int push(int [],int *,int);
int pop(int data[], int *num);
int size(int *nunmData);
int top(int data[],int *num);
int isFull(int *numData);
int isEmpty(int *numData);

int main()
{
  int stack[StackSize];
  int numData=0;
  int i;
  int quit=0; /*  1 for true, 0 for false */
  char command;
  int x;
          
  initial(stack, &numData); /* 初始化 */
         
  while(!quit)
  {
    for(i=0;i<StackSize;i++)
    printf("%d ", stack[i]);
    printf("\n");
              
    command = getUserCommand();
    
    switch(command)
        {
          case '1':
                    if(numData<StackSize)
                    {
                      x=getData();
                      push(stack, &numData, x);
                    }
                    break;
          case '2':
                    if(numData>0)
                    {
                      x=pop(stack, &numData);
                      printf("%d is poped!", x);
                    }
                    break;
          case '3':
                    top(stack,&numData);
                    break; 
          case '4':
                    size(&numData);
                    break;
          case '5':
                    isFull(&numData);
                    break;           
          case '6':
                    isEmpty(&numData);
                    break;
          case '7': /* quit */
                    quit=1;

    } /* end of switch */
 } /* end of while */
  
  printf("Program Terminated!");
 
}

void initial(int data[], int *num)
{
  int i;
  int *p;
  
/*  for(i=0;i<StackSize;i++)
      data[i]=(-1);
*/
      
   for(p=data;p<&data[StackSize];p++)
    *p=(-1);
        
    *num=0;  
}


char getUserCommand()
{
  char c,t;
  printf("1: push 2: pop 3: top 4: size 5: ifFull 6: isEmpty 7: quit  \n" );
  scanf(" %c", &c); /* & for memory address */
  return c;
}

int getData()
{
  int x;
  printf("Input a number:");
  scanf(" %d", &x);
  return x;
}

int push(int data[], int *num, int x)
{
  if(*num==StackSize)
  {
    return (-1);
  }
  else
  {
    data[*num]=x;
    (*num)++;
    return 0;
  }
}

int pop(int data[], int *num)
{
  int x;
  x = data[*num-1];
  data[*num-1]=(-1);
  (*num)--;
  return x;
}


int size(int *numData)
{
  printf("You enter the total number is:%d\n",*numData);
}
  
int top(int data[],int *num)
{
  printf("The top level is:%d\n",data[*num-1]);
}
  
int isFull(int *numData)
{
  if(*numData>9)
    printf("Yes!\n");
  else
    printf("No!\n");
}

int isEmpty(int *numData)
{
  if(*numData==0)
    printf("YES!\n");
  else
    printf("NO!\n");
            
}





