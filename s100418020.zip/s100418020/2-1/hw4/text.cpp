#include <iostream>
#include <cmath>
#include <climits>


using namespace std;

int main () 
