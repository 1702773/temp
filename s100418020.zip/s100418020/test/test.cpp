#include <iostream>

using namespace std;

int t_2(int x,int y);

int main()
{
  int a,b;
  cout << "Please enter two numbers: ";
  cin >> a >> b;
  cout << "Your answer is : " << t_2(a,b) << endl << endl;
  return 0;
}

int t_2(int x,int y)
{
  while( x!=0 )
  {
    if( y>x )
    {
      int temp;
      temp = x;
      x = y;
      y = temp;
    }
    x = x%y;
  }
  return y;
}

