#include <iostream>

using namespace std;
double y(double),x;

int main()
{
 
 cout << "Enter the number of light years:";
 cin >> x; 
 cout << x <<" light years = "<< y(x) <<" astronomical units." << endl;
} 

double y(double x)
{
 x = x*63240 ;
 return x;
}

