#include <iostream>
#include <cmath>
#include <climits>

using namespace std;

int main()
{
 long double z;
 long long double x,y;


 cout << "Enter the world's population: ";
 cin >> x ;
 cout << "Enter the population of the US: ";
 cin >> y ;
 
 z=((long double)y/(long double)x)*100 ;
 
 cout << "The population of the US is "<< z <<"% of the world population." << endl;
 
}

 
