#include <iostream>
#include "Student.h"

using namespace std;


int main()
{
std::string w;
float s;
Student st("12345", "Tony Wang");
st.showInfo();
st.showScore();
st.setHomework(1, 68);
st.setHomework(2, 72);
st.setHomework(3, 86);
st.setHomework(4, 62);
st.setHomework(5, 82);
st.setHomework(6, 60);
st.setHomework(7, 82);
st.setHomework(8, 77);
st.setSID("12334");
st.setName("uption");
st.setMidterm(68);
st.setFinal(82);
s=st.getHomework(8);
std::cout<< s <<std::endl;
s=st.getMidterm();
std::cout<< s <<std::endl;
s=st.getFinal();
std::cout<< s <<std::endl;
w=st.getSID();
std::cout<< w <<std::endl;
w=st.getName();
std::cout<< w <<std::endl;
w=st.getName();
std::cout<< w <<std::endl;
st.setRatio(0.2, 0.2, 0.6);
s=st.getHomeworkAverage(3);
std::cout<< s <<std::endl;
s=st.getScore();
std::cout<< s <<std::endl;
st.showInfo();
st.showScore();

return 0;

}

