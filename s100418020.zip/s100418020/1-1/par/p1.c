#include <stdio.h>
int main (void)
{
int x=0,y=0;
 
for (x=1;x<=5;x++)
 {
  
  for (y=0;y<x;y++)
   {
    printf("*");
   }
  
  printf("\n"); 
 }

return 0;
}


