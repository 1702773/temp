#ifndef studentEmployee_
#define studentEmployee_

#define pay_per_hour 100

#include <string>
#include "mytime.h"
class StudentEmployee
{
public:
  Time checkin;
  Time wHours;
  int salary;
  int id;
  char* name;
  StudentEmployee();
  StudentEmployee(int i, char * n);
  ~StudentEmployee();
  
  StudentEmployee & operator=(const StudentEmployee & s);
  friend std::ostream & operator<<(std::ostream & os,StudentEmployee & s);
};


#endif

