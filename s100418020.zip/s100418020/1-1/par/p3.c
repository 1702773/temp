#include <stdio.h>
int main(void)
{
int a,b,c=3,d=1,x,y;

  for (a=1;a<=4;a++)
  {
    for (b=1;b<=c;b++){printf("@");}
    
    for (b=1;b<=d;b++){printf("*");}
    
   printf("\n");
   c--;
   d+=2;
  }
  
  for (x=1;x<=2;x++)
  {
    printf("@");
    printf("*****\n");
  }
  


return 0;
}
