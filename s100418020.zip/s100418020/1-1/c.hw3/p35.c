#include <stdio.h>
int main(void)
{
int x1,x2,x3,x4,x5,x6,x7,x8,x9,x10,m1,m2,m3,m4,m5,m6,m7,m8,m9,m10,m11,m12,m13,m14,m15,m16;
printf("Enter the numbers from 1 to 16 in any order\n");
scanf("%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d%d",&m1,&m2,&m3,&m4,&m5,&m6,&m7,&m8,&m9,&m10,&m11,&m12,&m13,&m14,&m15,&m16);
printf("%3d %3d %3d %3d\n",m1,m2,m3,m4);
printf("%3d %3d %3d %3d\n",m5,m6,m7,m8);
printf("%3d %3d %3d %3d\n",m9,m10,m11,m12);
printf("%3d %3d %3d %3d\n",m13,m14,m15,m16);

x1=m1+m5+m9+m13;
x2=m2+m6+m10+m14;
x3=m3+m7+m11+m15;
x4=m4+m8+m12+m16;
printf("Row sums:%d %d %d %d\n",x1,x2,x3,x4);

x5=m1+m2+m3+m4;
x6=m5+m6+m7+m8;
x7=m9+m10+m11+m12;
x8=m13+m14+m15+m16;
printf("Column sums:%d %d %d %d\n",x5,x6,x7,x8);

x9=m1+m6+m11+m16;
x10=m4+m7+m10+m13;
printf("Diagonal sums:%d %d\n",x9,x10);

return 0;
}




