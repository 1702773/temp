#include <stdio.h>

int main (void)

{
int mm,dd,yyyy;
  
  printf("enter a date:");
  scanf("%2d/%2d/%4d",&mm,&dd,&yyyy);
  
  printf("You entered the day:%4d%2.2d%2.2d\n",yyyy,mm,dd);
  
  return 0;
}




