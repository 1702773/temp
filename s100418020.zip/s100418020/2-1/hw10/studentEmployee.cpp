#include <iostream>
#include <string>
#include "studentEmployee.h"

using namespace std;

StudentEmployee::StudentEmployee()
{
  id = 0;
  wHours.hours = wHours.minutes = 0;
  salary = 0;
  name = new char[21];
}

StudentEmployee::StudentEmployee(int i , char * n)
{
  name = new char[21];
  id = i;
  strcpy(name,n);
//  name = n;
  wHours.hours = wHours.minutes = 0;
  salary = 0;
//  name = new char[21];
}

StudentEmployee::~StudentEmployee()
{
}

ostream & operator<<(ostream & os , StudentEmployee & s)
{
  os << "(" << s.id << ")" << s.name
     << " Working Hours=" << s.wHours.hours << ":" << s.wHours.minutes
     << " Salary:NTD$" << s.salary << endl ;
}


StudentEmployee & StudentEmployee::operator=(const StudentEmployee & s)
{
  id = s.id;
  delete [] name;
  name = new char[21];
  strcpy(name,s.name);
  wHours = s.wHours;
  salary = s.salary;
}

