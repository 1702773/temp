use s100418020_test;

drop table if exists movies;

create table Movies

(

title char(100),
year int,
length int,
genre char(10)

 
);

insert into Movies (title,year,length,genre)values("Gone With the Wind","1939","231","drama");
insert into Movies (title,year,length,genre)values("Star Wars","1977","124","sciFi");
insert into Movies (title,year,length,genre)values("Wayne's World","1992","95","comedy");
 
select * from Movies;
