#include <stdio.h> 
#include <stdlib.h>

#include "stack.h"

int data [StackSize];
int num;

void stack_initial()
{
  int p;
  for(p=0;p<StackSize;p++)
    data[p]=(-1);
  num=0;
}

int push(int x)
{
  if(num==StackSize)
  {
    return (-1);
  }
  else
  {
    data[num]=x;
    num++;
    return 0;
  }
}

int pop()
{
  int x;
  x = data[num-1];
  data[num-1]=(-1);
  num--;
  return x;
}

void stack_show()
{
int i;
  if(num==0)
    printf("The stack is empty.\n");
  else
  {
    for(i=0;i<num;i++)
    {
      printf("| %d", data[i]);
    }
    printf("\n");
  }
}

/*
int main()
{
  int x;
  
  stack_initial();

  push(10);
  push(5);
  push(3);
  x=pop();  
  
  stack_show();
  
  printf("x=%d\n",x);

}
*/


