#include <stdio.h>

int main (void)
{

int x,y ;
printf("Enter two fractions separated by a plus sign:");
scanf("%d%d",&x,&y);

x=5*4+3*6;
y=6*4;

printf("The sun is %d/%d\n",x,y);


return 0;
}



