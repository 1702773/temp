#include <stdio.h>
#include <stdlib.h>

#include "LinkedList.h"


int main()
{
  int quit = 0;
  int data;
  
  while(!quit)
  {
    printf("please input a value:");
    scanf(" %d", &data); 

    if(data<0)
    {
      quit =1;
    }
    else
    {
      insert(data);
    }
  }
  
  showAllData();
  
  
  if(search(3)==1)
    printf("Number 3 is in the linked list.\n");
  else
    printf("Number 3 is not in the linked list.\n");  
  if(search(5)==1)
    printf("Number 5 is in the linked list.\n");
  else
    printf("Number 5 is not in the linked list.\n");  
  if(search(7)==1)
    printf("Number 7 is in the linked list.\n");
  else
    printf("Number 7 is not in the linked list.\n");  

  delete(3);
  delete(5);
  delete(7);
  
  showAllData();

    
}

