struct leaf 
{
int value;
struct leaf *right,*left;
};

typedef struct leaf Leaf_node;

void search(int data);
void insert(int data);
void PrintTree();




