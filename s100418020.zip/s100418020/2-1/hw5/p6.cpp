#include <iostream>
#include <string>

using namespace std;

struct inflatable 
{

 char name[20];
 float weight;
 int price;

};

int main() 
{

 inflatable commodity[3]=
 {
 
  {"Blue Pen",1.5,35},
  {"Red Ren",1.7,35},
  {"Pencil",0.5,10}
 
 };
 
cout << "The commodity name: " << commodity[0].name << endl;
cout << "weight: " << commodity[0].weight << endl;
cout << "price: " << commodity[0].price << endl;
cout << endl;     

cout << "The commodity name: " << commodity[1].name << endl;
cout << "weight: " << commodity[1].weight << endl;
cout << "price: " << commodity[1].price << endl;
cout << endl;
          
cout << "The commodity name: " << commodity[2].name << endl;
cout << "weight: " << commodity[2].weight << endl;
cout << "price: " << commodity[2].price << endl;          
cout << endl;


}


