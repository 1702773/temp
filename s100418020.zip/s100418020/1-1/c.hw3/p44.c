#include <stdio.h>

int main (void)
{

int x;

printf("Enter a number between 0 and 32767: ");
scanf("%d",&x);

printf("In octal,your number is:");

printf("%d",x/(8*8*8*8));
x=x%(8*8*8*8);

printf("%d",x/(8*8*8));
x=x%(8*8*8);

printf("%d",x/(8*8));
x=x%(8*8);

printf("%d",x/8);
x=x%8;

printf("%d\n",x);


return 0;
}



