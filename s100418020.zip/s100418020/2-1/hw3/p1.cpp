#include <iostream>
#include <cmath>
#include <climits>\

using namespace std;

int main()
{

int h,f,i;
cout << "Enter your height:___\b\b\b" ;
cin >> h;

f=h/12;
i=h%12;

cout << "Your height is " << f << " feet " << i << " inches." << endl ;

}
