#include <iostream>
#include <string>

using namespace std;

struct pizza_data 
{

 string name ;
 double diameter; 
 double weight;

};


int main ()
{

 pizza_data *pizza;
 pizza= new pizza_data;

 cout << "Please enter the pizza company: ";
 getline(cin,pizza->name);

 cout << "Please enter the pizza diameter: ";
 cin >> pizza->diameter;

 cout << "Please enter the pizza weight: ";
 cin >> pizza->weight;

 cout << endl;
  
 cout << "Pizza company: " << pizza->name << endl
      << "Pizza diameter: " << pizza->diameter << endl
      << "Pizza weight: " << pizza->weight << endl;

 delete pizza;
}

