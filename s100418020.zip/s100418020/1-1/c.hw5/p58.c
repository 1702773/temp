#include <stdio.h>
int main (void)
{
int a,x,y;


printf("Enter a 24-hour time: ");
scanf("%2d:%2d",&x,&y);
a=60*x+y;

if (a>172.5 && a<531.5) printf("Closest departure time is 8:00 a.m., arriving at 10:16 a.m.\n");
else if (a>531.5 && a<631) printf("Closest departure time is 9:43 a.m., arriving at 11:52 a.m.\n");

else if (a>631 && a<723) printf("Closest departure time is 11:19 a.m., arriving at 1:31 p.m.\n");
else if (a>723 && a<803.5) printf("Closest departure time is 12:47 p.m., arriving at 13:00 p.m.\n");

else if (a>803.5 && a<892.5) printf("Closest departure time is 2:00 p.m., arriving at 4:08 p.m.\n");
else if (a>892.5 && a<1042.5) printf("Closest departure time is 3:45 p.m., arriving at 5:55 p.m.\n");

else if (a>1042.5 && a<1222.5) printf("Closest departure time is 7:00 p.m., arriving at 9:20 p.m.\n");
else if (a>1222.5 || a<172.5) printf("Closest departure time is 9:45 p.m., arriving at 11:58 p.m.\n");




return 0;
}


