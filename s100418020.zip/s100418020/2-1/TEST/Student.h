#ifndef Student_H_
#define Student_H_
#include <iostream>
#include <string>

using namespace std;

class Student
{
  public:
      
      char name[20];
      char id[20];
  
      virtual void showInfo();
      Student();                                
                                
};


#endif


                                  


