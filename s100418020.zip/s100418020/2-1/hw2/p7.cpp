#include <iostream>

using namespace std ;

int main()
{
 int x,y ;

 cout << "Enter the number of hours:" ;
 cin >> x;

 cout << "Enter the number of minutes:" ; 
 cin >> y;

 cout << "Time: " << x << ":" << y << endl;

}

