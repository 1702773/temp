#include <stdio.h>
int main (void)
{
int i=0,j=0,k=4;

for (i=1;i<=5;i++)
{ 
  for (j=1;j<=k;j++) { printf("@"); }
  
  for (j=1;j<=i;j++) {printf("*"); }
  
  
  printf("\n");
  k--;  
}
 
return 0;
}



